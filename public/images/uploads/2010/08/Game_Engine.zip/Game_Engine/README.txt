# use the below command to compile on linux
# you will need the following packages
#	OpenGL, OpenAL, Glut
# To compile on mac you should use create and xcode project and add the following frameworks
#	OpenGL, OpenAL, Glut

g++ -o app main.cpp -LM Engine/*.cpp -lglut -lGLU -lalut