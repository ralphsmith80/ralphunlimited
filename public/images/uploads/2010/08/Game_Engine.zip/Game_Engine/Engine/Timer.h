
#ifndef __TIMER_H__
#define __TIMER_H__

#include <sys/time.h>

class Timer
{
private:
	double timer_start;
	double stopwatch_start;

public:
	Timer(void);
	~Timer(void);
	double getTimer();
	double getStartTimeMillis();

	void sleep(int ms);
	void reset();
	bool stopwatch(int ms);
	
	static double timeGetTime();
	static double timeGetTimeMs();

};

#endif
