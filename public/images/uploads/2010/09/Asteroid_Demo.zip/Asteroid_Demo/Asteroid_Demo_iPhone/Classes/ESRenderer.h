//
//  ESRenderer.h
//  Asteroids_iphone
//
//  Created by Ralph Smith on 9/5/10.
//  Copyright Ralph Smith 2010. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

#import <OpenGLES/EAGL.h>
#import <OpenGLES/EAGLDrawable.h>

@protocol ESRenderer <NSObject>

- (void)render;
- (BOOL)resizeFromLayer:(CAEAGLLayer *)layer;

@end
