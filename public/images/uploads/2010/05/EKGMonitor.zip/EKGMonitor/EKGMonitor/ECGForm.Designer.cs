namespace ECGMonitor
{
    partial class ECGForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCancel = new System.Windows.Forms.Button();
            this.openBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Button();
            this.dataBitcomboBox = new System.Windows.Forms.ComboBox();
            this.portComboBox = new System.Windows.Forms.ComboBox();
            this.parityComboBox = new System.Windows.Forms.ComboBox();
            this.baudComboBox = new System.Windows.Forms.ComboBox();
            this.StopBitComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.stopWriteBtn = new System.Windows.Forms.Button();
            this.writeBtn = new System.Windows.Forms.Button();
            this.alarmTxtBx = new System.Windows.Forms.TextBox();
            this.rateTxtBx = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.GPSStopBits = new System.Windows.Forms.ComboBox();
            this.GPSBuad = new System.Windows.Forms.ComboBox();
            this.GPSDataBits = new System.Windows.Forms.ComboBox();
            this.GPSParity = new System.Windows.Forms.ComboBox();
            this.GPSPort = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.longitudeTxtBx = new System.Windows.Forms.TextBox();
            this.lattitudeTxtBx = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.applyBtn = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.triggerTxtBx = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.gainTxtBx = new System.Windows.Forms.TextBox();
            this.ECGTraceView = new ECGMonitor.TraceView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // btCancel
            // 
            this.btCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btCancel.Location = new System.Drawing.Point(59, 95);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(97, 32);
            this.btCancel.TabIndex = 5;
            this.btCancel.Text = "Exit";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // openBtn
            // 
            this.openBtn.Location = new System.Drawing.Point(6, 19);
            this.openBtn.Name = "openBtn";
            this.openBtn.Size = new System.Drawing.Size(97, 32);
            this.openBtn.TabIndex = 1;
            this.openBtn.Text = "Start";
            this.openBtn.UseVisualStyleBackColor = true;
            this.openBtn.Click += new System.EventHandler(this.openBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.Location = new System.Drawing.Point(110, 19);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(97, 32);
            this.closeBtn.TabIndex = 2;
            this.closeBtn.Text = "Stop";
            this.closeBtn.UseVisualStyleBackColor = true;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // dataBitcomboBox
            // 
            this.dataBitcomboBox.FormattingEnabled = true;
            this.dataBitcomboBox.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.dataBitcomboBox.Location = new System.Drawing.Point(11, 112);
            this.dataBitcomboBox.Name = "dataBitcomboBox";
            this.dataBitcomboBox.Size = new System.Drawing.Size(76, 21);
            this.dataBitcomboBox.TabIndex = 8;
            // 
            // portComboBox
            // 
            this.portComboBox.FormattingEnabled = true;
            this.portComboBox.Location = new System.Drawing.Point(11, 32);
            this.portComboBox.Name = "portComboBox";
            this.portComboBox.Size = new System.Drawing.Size(76, 21);
            this.portComboBox.TabIndex = 6;
            // 
            // parityComboBox
            // 
            this.parityComboBox.FormattingEnabled = true;
            this.parityComboBox.Location = new System.Drawing.Point(11, 152);
            this.parityComboBox.Name = "parityComboBox";
            this.parityComboBox.Size = new System.Drawing.Size(76, 21);
            this.parityComboBox.TabIndex = 9;
            // 
            // baudComboBox
            // 
            this.baudComboBox.FormattingEnabled = true;
            this.baudComboBox.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "28800",
            "36000",
            "38400",
            "56000",
            "57600",
            "115000"});
            this.baudComboBox.Location = new System.Drawing.Point(11, 72);
            this.baudComboBox.Name = "baudComboBox";
            this.baudComboBox.Size = new System.Drawing.Size(76, 21);
            this.baudComboBox.TabIndex = 7;
            // 
            // StopBitComboBox
            // 
            this.StopBitComboBox.FormattingEnabled = true;
            this.StopBitComboBox.Location = new System.Drawing.Point(11, 192);
            this.StopBitComboBox.Name = "StopBitComboBox";
            this.StopBitComboBox.Size = new System.Drawing.Size(76, 21);
            this.StopBitComboBox.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Port";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Baud Rate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Parity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Data Bits";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 176);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Stop Bits";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.StopBitComboBox);
            this.groupBox1.Controls.Add(this.baudComboBox);
            this.groupBox1.Controls.Add(this.dataBitcomboBox);
            this.groupBox1.Controls.Add(this.parityComboBox);
            this.groupBox1.Controls.Add(this.portComboBox);
            this.groupBox1.Location = new System.Drawing.Point(550, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(104, 226);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ECG Settings";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.stopWriteBtn);
            this.groupBox2.Controls.Add(this.writeBtn);
            this.groupBox2.Controls.Add(this.openBtn);
            this.groupBox2.Controls.Add(this.closeBtn);
            this.groupBox2.Controls.Add(this.btCancel);
            this.groupBox2.Location = new System.Drawing.Point(550, 244);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(213, 134);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Operations";
            // 
            // stopWriteBtn
            // 
            this.stopWriteBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.stopWriteBtn.Location = new System.Drawing.Point(110, 57);
            this.stopWriteBtn.Name = "stopWriteBtn";
            this.stopWriteBtn.Size = new System.Drawing.Size(97, 32);
            this.stopWriteBtn.TabIndex = 4;
            this.stopWriteBtn.Text = "Stop Recording";
            this.stopWriteBtn.UseVisualStyleBackColor = true;
            this.stopWriteBtn.Click += new System.EventHandler(this.stopWriteBtn_Click);
            // 
            // writeBtn
            // 
            this.writeBtn.Location = new System.Drawing.Point(6, 57);
            this.writeBtn.Name = "writeBtn";
            this.writeBtn.Size = new System.Drawing.Size(97, 32);
            this.writeBtn.TabIndex = 3;
            this.writeBtn.Text = "Record Data";
            this.writeBtn.UseVisualStyleBackColor = true;
            this.writeBtn.Click += new System.EventHandler(this.writeBtn_Click);
            // 
            // alarmTxtBx
            // 
            this.alarmTxtBx.Enabled = false;
            this.alarmTxtBx.Location = new System.Drawing.Point(112, 34);
            this.alarmTxtBx.Name = "alarmTxtBx";
            this.alarmTxtBx.Size = new System.Drawing.Size(179, 20);
            this.alarmTxtBx.TabIndex = 11;
            // 
            // rateTxtBx
            // 
            this.rateTxtBx.Enabled = false;
            this.rateTxtBx.Location = new System.Drawing.Point(6, 34);
            this.rateTxtBx.Name = "rateTxtBx";
            this.rateTxtBx.Size = new System.Drawing.Size(100, 20);
            this.rateTxtBx.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Heart Rate";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(119, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Alarm";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.GPSStopBits);
            this.groupBox3.Controls.Add(this.GPSBuad);
            this.groupBox3.Controls.Add(this.GPSDataBits);
            this.groupBox3.Controls.Add(this.GPSParity);
            this.groupBox3.Controls.Add(this.GPSPort);
            this.groupBox3.Location = new System.Drawing.Point(660, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(104, 226);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "GPS Settings";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 175);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "Stop Bits";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "Data Bits";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 135);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Parity";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 55);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(58, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "Baud Rate";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(26, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "Port";
            // 
            // GPSStopBits
            // 
            this.GPSStopBits.FormattingEnabled = true;
            this.GPSStopBits.Location = new System.Drawing.Point(16, 191);
            this.GPSStopBits.Name = "GPSStopBits";
            this.GPSStopBits.Size = new System.Drawing.Size(76, 21);
            this.GPSStopBits.TabIndex = 15;
            // 
            // GPSBuad
            // 
            this.GPSBuad.FormattingEnabled = true;
            this.GPSBuad.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "28800",
            "36000",
            "38400",
            "57600",
            "115000"});
            this.GPSBuad.Location = new System.Drawing.Point(16, 71);
            this.GPSBuad.Name = "GPSBuad";
            this.GPSBuad.Size = new System.Drawing.Size(76, 21);
            this.GPSBuad.TabIndex = 12;
            // 
            // GPSDataBits
            // 
            this.GPSDataBits.FormattingEnabled = true;
            this.GPSDataBits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.GPSDataBits.Location = new System.Drawing.Point(16, 111);
            this.GPSDataBits.Name = "GPSDataBits";
            this.GPSDataBits.Size = new System.Drawing.Size(76, 21);
            this.GPSDataBits.TabIndex = 13;
            // 
            // GPSParity
            // 
            this.GPSParity.FormattingEnabled = true;
            this.GPSParity.Location = new System.Drawing.Point(16, 151);
            this.GPSParity.Name = "GPSParity";
            this.GPSParity.Size = new System.Drawing.Size(76, 21);
            this.GPSParity.TabIndex = 14;
            // 
            // GPSPort
            // 
            this.GPSPort.FormattingEnabled = true;
            this.GPSPort.Location = new System.Drawing.Point(16, 31);
            this.GPSPort.Name = "GPSPort";
            this.GPSPort.Size = new System.Drawing.Size(76, 21);
            this.GPSPort.TabIndex = 11;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.longitudeTxtBx);
            this.groupBox4.Controls.Add(this.lattitudeTxtBx);
            this.groupBox4.Location = new System.Drawing.Point(320, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(224, 63);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Location";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(113, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(74, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "Longitude (W)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 13);
            this.label13.TabIndex = 2;
            this.label13.Text = "Lattitude (N)";
            // 
            // longitudeTxtBx
            // 
            this.longitudeTxtBx.Enabled = false;
            this.longitudeTxtBx.Location = new System.Drawing.Point(112, 32);
            this.longitudeTxtBx.Name = "longitudeTxtBx";
            this.longitudeTxtBx.Size = new System.Drawing.Size(100, 20);
            this.longitudeTxtBx.TabIndex = 1;
            // 
            // lattitudeTxtBx
            // 
            this.lattitudeTxtBx.Enabled = false;
            this.lattitudeTxtBx.Location = new System.Drawing.Point(6, 32);
            this.lattitudeTxtBx.Name = "lattitudeTxtBx";
            this.lattitudeTxtBx.Size = new System.Drawing.Size(100, 20);
            this.lattitudeTxtBx.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.alarmTxtBx);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.rateTxtBx);
            this.groupBox5.Location = new System.Drawing.Point(12, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(301, 63);
            this.groupBox5.TabIndex = 17;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "ECG Information";
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.applyBtn);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.triggerTxtBx);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.gainTxtBx);
            this.groupBox6.Location = new System.Drawing.Point(550, 384);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(213, 106);
            this.groupBox6.TabIndex = 19;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Alterations";
            // 
            // applyBtn
            // 
            this.applyBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.applyBtn.Location = new System.Drawing.Point(59, 64);
            this.applyBtn.Name = "applyBtn";
            this.applyBtn.Size = new System.Drawing.Size(97, 32);
            this.applyBtn.TabIndex = 6;
            this.applyBtn.Text = "Apply";
            this.applyBtn.UseVisualStyleBackColor = true;
            this.applyBtn.Click += new System.EventHandler(this.applyBtn_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(109, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Trigger";
            // 
            // triggerTxtBx
            // 
            this.triggerTxtBx.Location = new System.Drawing.Point(110, 38);
            this.triggerTxtBx.Name = "triggerTxtBx";
            this.triggerTxtBx.Size = new System.Drawing.Size(97, 20);
            this.triggerTxtBx.TabIndex = 3;
            this.triggerTxtBx.TextChanged += new System.EventHandler(this.triggerTxtBx_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Gain";
            // 
            // gainTxtBx
            // 
            this.gainTxtBx.Location = new System.Drawing.Point(6, 38);
            this.gainTxtBx.Name = "gainTxtBx";
            this.gainTxtBx.Size = new System.Drawing.Size(97, 20);
            this.gainTxtBx.TabIndex = 0;
            this.gainTxtBx.TextChanged += new System.EventHandler(this.gainTxtBx_TextChanged);
            // 
            // ECGTraceView
            // 
            this.ECGTraceView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ECGTraceView.BackColor = System.Drawing.SystemColors.Window;
            this.ECGTraceView.BufferLength = 0;
            this.ECGTraceView.DataMax = 255F;
            this.ECGTraceView.DataMin = 0F;
            this.ECGTraceView.GridColor = System.Drawing.Color.Green;
            this.ECGTraceView.GridOffset = 1F;
            this.ECGTraceView.Length = 0;
            this.ECGTraceView.Location = new System.Drawing.Point(12, 81);
            this.ECGTraceView.Name = "ECGTraceView";
            this.ECGTraceView.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.ECGTraceView.Position = 0;
            this.ECGTraceView.RecordIndictor = false;
            this.ECGTraceView.SampleRate = 100F;
            this.ECGTraceView.ShowGrid = true;
            this.ECGTraceView.ShowScrollBar = false;
            this.ECGTraceView.Size = new System.Drawing.Size(532, 409);
            this.ECGTraceView.TabIndex = 0;
            this.ECGTraceView.TimeMark = new System.DateTime(((long)(0)));
            this.ECGTraceView.YMaxMeasure = 93.75F;
            this.ECGTraceView.YMinMeasure = -93.75F;
            // 
            // ECGForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(775, 496);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ECGTraceView);
            this.Name = "ECGForm";
            this.Text = "ECG Monitor";
            this.Load += new System.EventHandler(this.ECGForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TraceView ECGTraceView;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button openBtn;
        private System.Windows.Forms.Button closeBtn;
        private System.Windows.Forms.ComboBox dataBitcomboBox;
        private System.Windows.Forms.ComboBox portComboBox;
        private System.Windows.Forms.ComboBox parityComboBox;
        private System.Windows.Forms.ComboBox baudComboBox;
        private System.Windows.Forms.ComboBox StopBitComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox alarmTxtBx;
        private System.Windows.Forms.TextBox rateTxtBx;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox GPSStopBits;
        private System.Windows.Forms.ComboBox GPSBuad;
        private System.Windows.Forms.ComboBox GPSDataBits;
        private System.Windows.Forms.ComboBox GPSParity;
        private System.Windows.Forms.ComboBox GPSPort;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox longitudeTxtBx;
        private System.Windows.Forms.TextBox lattitudeTxtBx;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button writeBtn;
        private System.Windows.Forms.Button stopWriteBtn;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox gainTxtBx;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button applyBtn;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox triggerTxtBx;
    }
}

