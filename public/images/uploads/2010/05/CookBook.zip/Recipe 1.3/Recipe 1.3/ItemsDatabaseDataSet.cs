﻿namespace Recipe_1._3 {
    
    
    public partial class ItemsDatabaseDataSet {
    }
}
namespace Recipe_1._3 {
    
    
    public partial class ItemsDatabaseDataSet {
    }
}
